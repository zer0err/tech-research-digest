"""Run real checks and retain exit codes, logs, versions and input hashes."""
import hashlib
import importlib.metadata
import json
import platform
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / 'verification'


def main():
    checks = [
        ('frameworks', [sys.executable, '-m', 'pytest', '-q', str(REPORT/'test_frameworks_cpu.py')]),
        ('agent-and-mechanisms', [sys.executable, '-m', 'unittest', 'discover', '-s', str(ROOT/'labs'), '-p', 'test_*.py', '-v']),
    ]
    results = []
    for name, command in checks:
        result = subprocess.run(command, capture_output=True, text=True, timeout=180)
        (REPORT/(name+'.log')).write_text(result.stdout+result.stderr)
        results.append({'name': name, 'exit_code': result.returncode, 'command': command})
        print(name, result.returncode, flush=True)
    examples = []
    for lesson in json.loads((ROOT/'preview.json').read_text())['lessons']:
        uid = lesson['id']
        result = subprocess.run([sys.executable, 'lab.py', uid], cwd=ROOT/'labs', capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            json.loads(result.stdout)
        examples.append({'id': uid, 'exit_code': result.returncode})
    inputs = [* (ROOT/'labs').glob('*.py'), REPORT/'test_frameworks_cpu.py', ROOT/'requirements-cpu.lock']
    evidence = {
        'time': datetime.now(ZoneInfo('Asia/Taipei')).isoformat(),
        'python': sys.version, 'platform': platform.platform(),
        'versions': {name: importlib.metadata.version(name) for name in
                     ['torch', 'transformers', 'langgraph', 'llama-index-core', 'chromadb', 'pytest']},
        'checks': results, 'examples': examples,
        'sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},
        'scope': 'Tiny random models and synthetic data; no pretrained quality, paid API, GPU or full framework course certification.',
    }
    (REPORT/'results.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2)+'\n')
    return int(any(item['exit_code'] for item in results+examples))


if __name__ == '__main__':
    raise SystemExit(main())
