# CPU/Mac 真实组件验证

2026-11-05，Apple Silicon / Python 3.12。无需 GPU、模型下载或 API 密钥。
实际版本、执行时间、输入 SHA256 见 results.json，原始输出见两个 .log 文件。

在系列根目录运行（安装依赖需网络）：

```bash
uv venv --python python3.12 .verify-venv
uv pip sync --python .verify-venv/bin/python requirements-cpu.lock
.verify-venv/bin/python verification/run_checks.py
```

单独检查 BERT：

```bash
.verify-venv/bin/python -m pytest -v verification/test_frameworks_cpu.py -k bert
```

测试文件包含完整实现与断言。使用随机初始化微型模型、合成数据，不能当作中文情感分析准确率或生成质量证据。

| 对应单元 | 已执行 | 验收边界 |
|---|---|---|
| 02 Hugging Face | 中文词表分词与重载 | 无预训练权重 |
| 03 BERT | 前反向、两步更新、保存重载 | 非中文评价训练效果 |
| 04 GPT-2 | 因果损失、更新、生成、重载 | 无生成质量结论 |
| 09 蒸馏 | KL 损失与学生参数更新 | 线性模型，非大模型压缩 |
| 15 LlamaIndex | 真实索引和检索 | 关键词向量，非语义质量 |
| 16 Chroma | 存储、过滤、查询、重开连接、删除 | 非跨进程恢复与压力测试 |
| 23 LangGraph | 真实条件图与拒答分支 | 确定性节点，无 LLM |
| 01/26 Agent | 工具白名单、引用ID、JSON与异常边界 | 引用存在不证明事实正确 |

修复记录：Transformers 5.22.1 的分词器使用 `vocab` 参数；旧 `vocab_file` 写法导致中文全部变成未知词。已用中文差异与保存重载断言验证，写法以锁定版本为准。

未验证的课程项目见 VALIDATION.md，不能用这些组件测试代替完整项目验收。
