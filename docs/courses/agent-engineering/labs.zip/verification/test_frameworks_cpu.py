"""Actual framework tests on tiny/synthetic inputs, NOT pretrained-model quality tests."""
import os
from typing import TypedDict

os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['ANONYMIZED_TELEMETRY'] = 'False'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'


def test_bert_tokenizer_with_local_chinese_vocabulary(tmp_path):
    from transformers import BertTokenizer
    vocabulary = ['[PAD]', '[UNK]', '[CLS]', '[SEP]', '[MASK]', '服', '务', '好', '差']
    path = tmp_path/'vocab.txt'
    path.write_text('\n'.join(vocabulary)+'\n')
    tokenizer = BertTokenizer(vocab=str(path), do_lower_case=False)
    good = tokenizer('服务好')
    bad = tokenizer('服务差')
    assert good['input_ids'] != bad['input_ids']
    assert good['input_ids'][0] == tokenizer.cls_token_id


def test_bert_real_forward_backward_save_reload(tmp_path):
    import torch
    from transformers import BertConfig, BertForSequenceClassification
    torch.set_num_threads(1)
    torch.manual_seed(17)
    model = BertForSequenceClassification(BertConfig(vocab_size=32, hidden_size=16, num_hidden_layers=1,
                                                     num_attention_heads=2, intermediate_size=32, num_labels=2))
    inputs = torch.tensor([[2, 5, 6, 3], [2, 7, 8, 3]])
    labels = torch.tensor([0, 1])
    before = model.classifier.weight.detach().clone()
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.01)
    for _ in range(2):
        optimizer.zero_grad()
        loss = model(input_ids=inputs, labels=labels).loss
        assert torch.isfinite(loss)
        loss.backward()
        optimizer.step()
    assert not torch.equal(before, model.classifier.weight)
    model.eval()
    model.save_pretrained(tmp_path/'bert')
    restored = BertForSequenceClassification.from_pretrained(tmp_path/'bert', local_files_only=True)
    restored.eval()
    assert torch.allclose(model(inputs).logits, restored(inputs).logits)


def test_gpt2_real_causal_training_and_generation(tmp_path):
    import torch
    from transformers import GPT2Config, GPT2LMHeadModel
    torch.manual_seed(23)
    model = GPT2LMHeadModel(GPT2Config(vocab_size=32, n_positions=32, n_ctx=32, n_embd=16,
                                     n_layer=1, n_head=2, bos_token_id=1, eos_token_id=2, pad_token_id=0))
    ids = torch.tensor([[1, 5, 6, 7, 2]])
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.005)
    before = model.transformer.wte.weight.detach().clone()
    loss = model(input_ids=ids, labels=ids).loss
    loss.backward()
    optimizer.step()
    assert not torch.equal(before, model.transformer.wte.weight)
    model.eval()
    generated = model.generate(ids[:, :2], max_new_tokens=3, do_sample=False)
    assert 2 < generated.shape[1] <= 5
    model.save_pretrained(tmp_path/'gpt2')
    restored = GPT2LMHeadModel.from_pretrained(tmp_path/'gpt2', local_files_only=True)
    restored.eval()
    assert torch.allclose(model(ids).logits, restored(ids).logits)


def test_real_distillation_gradient_step():
    import torch
    torch.manual_seed(31)
    teacher, student = torch.nn.Linear(4, 3), torch.nn.Linear(4, 3)
    x = torch.randn(5, 4)
    with torch.no_grad():
        target = torch.softmax(teacher(x)/2, dim=-1)
    optimizer = torch.optim.SGD(student.parameters(), lr=0.1)
    before = student.weight.detach().clone()
    loss = torch.nn.functional.kl_div(torch.log_softmax(student(x)/2, dim=-1), target, reduction='batchmean')*4
    loss.backward()
    optimizer.step()
    assert torch.isfinite(loss)
    assert not torch.equal(before, student.weight)


def test_langgraph_real_conditional_execution():
    from langgraph.graph import END, START, StateGraph
    class State(TypedDict):
        query: str
        hits: list[str]
        status: str
    def retrieve(state):
        return {'hits': ['DEMO-1'] if '服务期' in state['query'] else []}
    builder = StateGraph(State)
    builder.add_node('retrieve', retrieve)
    builder.add_node('answer', lambda state: {'status': 'answered'})
    builder.add_node('abstain', lambda state: {'status': 'abstained'})
    builder.add_edge(START, 'retrieve')
    builder.add_conditional_edges('retrieve', lambda state: 'answer' if state['hits'] else 'abstain')
    builder.add_edge('answer', END)
    builder.add_edge('abstain', END)
    graph = builder.compile()
    assert graph.invoke({'query': '服务期', 'hits': [], 'status': ''})['status'] == 'answered'
    assert graph.invoke({'query': '未知', 'hits': [], 'status': ''})['status'] == 'abstained'


def test_chroma_real_persistence_query_filter_delete(tmp_path):
    import chromadb
    from chromadb.config import Settings
    client = chromadb.PersistentClient(path=str(tmp_path/'chroma'), settings=Settings(anonymized_telemetry=False))
    collection = client.get_or_create_collection('course-verify', embedding_function=None)
    collection.add(ids=['a', 'b'], documents=['服务期30天', '电池不得浸水'], embeddings=[[1., 0.], [0., 1.]],
                   metadatas=[{'edition': 'current'}, {'edition': 'old'}])
    result = collection.query(query_embeddings=[[1., 0.]], n_results=1, where={'edition': 'current'})
    assert result['ids'] == [['a']]
    reopened = chromadb.PersistentClient(path=str(tmp_path/'chroma'), settings=Settings(anonymized_telemetry=False))
    persisted = reopened.get_collection('course-verify', embedding_function=None)
    assert persisted.count() == 2
    persisted.delete(ids=['b'])
    assert persisted.count() == 1


def test_llamaindex_real_index_retrieval_no_remote_model():
    from llama_index.core import Document, VectorStoreIndex
    from llama_index.core.base.embeddings.base import BaseEmbedding
    class KeywordEmbedding(BaseEmbedding):
        """Toy embedding to test framework wiring, not a neural semantic model."""
        def _get_query_embedding(self, query):
            return [float('服务期' in query), float('电池' in query), 0.001]
        async def _aget_query_embedding(self, query):
            return self._get_query_embedding(query)
        def _get_text_embedding(self, text):
            return self._get_query_embedding(text)
    index = VectorStoreIndex.from_documents(
        [Document(text='服务期30天', id_='a'), Document(text='电池不得浸水', id_='b')], embed_model=KeywordEmbedding())
    hits = index.as_retriever(similarity_top_k=1).retrieve('电池')
    assert len(hits) == 1
    assert '电池' in hits[0].text


def test_tokenizer_save_reload_preserves_chinese_ids(tmp_path):
    from transformers import BertTokenizer
    vocabulary = ['[PAD]', '[UNK]', '[CLS]', '[SEP]', '[MASK]', '服', '务', '好', '差']
    tokenizer = BertTokenizer(vocab=dict(zip(vocabulary, range(len(vocabulary)))), do_lower_case=False)
    tokenizer.save_pretrained(tmp_path/'tokenizer')
    restored = BertTokenizer.from_pretrained(tmp_path/'tokenizer', local_files_only=True)
    assert restored('服务好')['input_ids'] == tokenizer('服务好')['input_ids']
    assert restored.unk_token_id not in restored('服务好')['input_ids']
