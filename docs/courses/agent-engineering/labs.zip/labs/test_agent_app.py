import json
import os
import unittest
from unittest.mock import patch

from agent_app import LiveClient, offline_model, run_agent


class AgentTests(unittest.TestCase):
    def test_readonly_answer(self):
        answer = run_agent('售后服务期', offline_model)
        self.assertEqual(answer['status'], 'answered')
        self.assertEqual(answer['citations'], ['DEMO-1'])

    def test_no_evidence_uses_only_one_call(self):
        calls = []
        def model(system, prompt):
            calls.append(1)
            return offline_model(system, prompt)
        self.assertEqual(run_agent('未知', model)['status'], 'abstained')
        self.assertEqual(len(calls), 1)

    def test_model_cannot_authorize_shell(self):
        with self.assertRaises(ValueError):
            run_agent('test', lambda *args: json.dumps({'tool': 'shell', 'arguments': {'query': 'test'}}))

    def test_fake_citation_is_rejected(self):
        def model(system, prompt):
            if json.loads(prompt)['phase'] == 'plan':
                return offline_model(system, prompt)
            return json.dumps({'answer': 'x', 'citations': ['invented']})
        with self.assertRaises(ValueError):
            run_agent('售后服务期', model)

    def test_live_calls_require_separate_authorization(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(ValueError):
                LiveClient()

    def test_live_request_contract_uses_no_real_network(self):
        class Response:
            def __enter__(self):
                return self
            def __exit__(self, *args):
                return False
            def read(self, limit):
                return json.dumps({'choices': [{'finish_reason': 'stop', 'message': {'content': '{}'}}]}).encode()
        env = {'COURSE_ALLOW_PAID_CALLS': 'yes', 'COURSE_PROVIDER': 'mimo', 'COURSE_MODEL': 'test-model', 'COURSE_API_KEY': 'test-key'}
        with patch.dict(os.environ, env, clear=True), patch('agent_app.urlopen', return_value=Response()) as network:
            client = LiveClient()
            client('system', 'prompt')
            request = network.call_args.args[0]
            self.assertEqual(json.loads(request.data)['thinking'], {'type': 'disabled'})
            client('system', 'prompt')
            with self.assertRaises(ValueError):
                client('system', 'prompt')
            self.assertEqual(network.call_count, 2)


if __name__ == '__main__':
    unittest.main()
