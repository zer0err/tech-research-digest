import json
import unittest

from agent_app import offline_model, parse_object, run_agent


class AgentAdversarialTests(unittest.TestCase):
    def test_bad_queries(self):
        for query in ['', ' ', None, [], 'x'*101]:
            with self.subTest(query=query), self.assertRaises(ValueError):
                run_agent(query, offline_model)

    def test_json_parser_is_strict(self):
        for text in ['[]', 'null', '{', '```json\n{}\n```', '{"x":1,"x":2}', '{"x":NaN}', 'x'*16001, None]:
            with self.subTest(text=str(text)[:50]), self.assertRaises((ValueError, TypeError)):
                parse_object(text)

    def test_invalid_actions(self):
        actions = [
            {}, {'tool':'shell','arguments':{'query':'x'}},
            {'tool':'lookup','arguments':[]},
            {'tool':'lookup','arguments':{'query':'x','write':True}},
            {'tool':'lookup','arguments':{'query':'x'*101}},
            {'tool':'lookup','arguments':{'query':None}},
        ]
        for action in actions:
            with self.subTest(action=action), self.assertRaises(ValueError):
                run_agent('售后服务期', lambda *args:json.dumps(action))

    def test_invalid_answers_and_citations(self):
        answers = [
            {'answer':'x','citations':[]}, {'answer':'x','citations':['FAKE']},
            {'answer':'x','citations':'DEMO-1'}, {'answer':[],'citations':['DEMO-1']},
            {'answer':'','citations':['DEMO-1']}, {'answer':'x'*4001,'citations':['DEMO-1']},
        ]
        for answer in answers:
            def model(system, prompt, answer=answer):
                return offline_model(system,prompt) if json.loads(prompt)['phase']=='plan' else json.dumps(answer)
            with self.subTest(answer=str(answer)[:80]), self.assertRaises(ValueError):
                run_agent('售后服务期',model)

    def test_valid_reference_does_not_imply_truth(self):
        def liar(system,prompt):
            if json.loads(prompt)['phase']=='plan':
                return offline_model(system,prompt)
            return json.dumps({'answer':'服务期999天','citations':['DEMO-1']})
        answer=run_agent('售后服务期',liar)
        self.assertIn('factual_support_not_proven',answer['verification'])

    def test_provider_exception_propagates_without_auto_retry(self):
        calls=[]
        def unavailable(*args):
            calls.append(1)
            raise TimeoutError('synthetic timeout')
        with self.assertRaises(TimeoutError):
            run_agent('售后服务期',unavailable)
        self.assertEqual(len(calls),1)


if __name__=='__main__':
    unittest.main()
