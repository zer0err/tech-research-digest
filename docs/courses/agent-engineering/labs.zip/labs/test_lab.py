import unittest

from lab import agent, classify_metrics, cosine, quantize, retrieve, run, safe_tool, validate_messages


class LabTests(unittest.TestCase):
    def test_schema_rejects_missing_role(self):
        with self.assertRaises(ValueError):
            validate_messages([{'content': 'x'}])

    def test_imbalanced_metrics_are_not_accuracy_only(self):
        result = classify_metrics([0, 0, 0, 1], [0, 0, 0, 0])
        self.assertEqual(result['accuracy'], 0.75)
        self.assertLess(result['macro_f1'], 0.5)

    def test_cosine_and_dimension_validation(self):
        self.assertEqual(cosine([1, 0], [1, 0]), 1)
        self.assertEqual(cosine([1, 0], [0, 1]), 0)
        with self.assertRaises(ValueError):
            cosine([1], [1, 2])

    def test_quantization_error_and_invalid_scale(self):
        self.assertLessEqual(quantize([0.12, -0.28], 0.1)['max_error'], 0.05)
        with self.assertRaises(ValueError):
            quantize([1], 0)

    def test_no_evidence_abstains(self):
        self.assertEqual(retrieve('不存在'), [])
        self.assertEqual(agent('不存在')['events'][-1]['state'], 'abstained')
        self.assertFalse(agent('服务期')['llm_called'])

    def test_tool_schema_and_permissions(self):
        with self.assertRaises(ValueError):
            safe_tool('shell', {'query': 'x'})
        with self.assertRaises(ValueError):
            safe_tool('lookup', {'query': 'x', 'extra': True})
        with self.assertRaises(ValueError):
            safe_tool('lookup', {'query': 'x'*101})

    def test_shards_do_not_overlap(self):
        result = run('08-distributed-training')
        a, b = result['shards']
        self.assertFalse(set(a) & set(b))
        self.assertEqual(sorted(a+b), list(range(8)))

    def test_parity_reports_template_and_sampling(self):
        self.assertEqual(run('11-serving-parity')['mismatches'], ['template', 'temperature'])

    def test_capstone(self):
        self.assertTrue(run('26-capstone')['all_passed'])


if __name__ == '__main__':
    unittest.main()
