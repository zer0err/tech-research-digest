"""Offline teaching experiments. These are not framework or model benchmarks."""
from __future__ import annotations

import hashlib
import json
import math
import sys
from collections import Counter


def validate_messages(messages):
    if not isinstance(messages, list) or not messages:
        raise ValueError('messages must be a nonempty list')
    for message in messages:
        if set(message) != {'role', 'content'} or message['role'] not in {'system', 'user', 'assistant'}:
            raise ValueError('invalid message schema')
        if not isinstance(message['content'], str) or not message['content'].strip():
            raise ValueError('empty message')
    return True


def cosine(a, b):
    if len(a) != len(b):
        raise ValueError('embedding dimension mismatch')
    denominator = math.sqrt(sum(x*x for x in a)*sum(x*x for x in b))
    return sum(x*y for x, y in zip(a, b)) / denominator if denominator else 0.0


def classify_metrics(gold, predicted):
    if len(gold) != len(predicted) or not gold:
        raise ValueError('invalid evaluation batch')
    scores = []
    for label in sorted(set(gold) | set(predicted)):
        tp = sum(a == b == label for a, b in zip(gold, predicted))
        fp = sum(a != label and b == label for a, b in zip(gold, predicted))
        fn = sum(a == label and b != label for a, b in zip(gold, predicted))
        scores.append(2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0)
    return {'accuracy': sum(a == b for a, b in zip(gold, predicted))/len(gold), 'macro_f1': sum(scores)/len(scores)}


def quantize(values, scale):
    if scale <= 0:
        raise ValueError('scale must be positive')
    integers = [max(-128, min(127, round(x/scale))) for x in values]
    restored = [x*scale for x in integers]
    return {'integers': integers, 'max_error': max(abs(a-b) for a, b in zip(values, restored))}


DOCS = [
    {'id': 'DEMO-1', 'text': '演示设备 售后服务期 30 天', 'effective': '2026-01-01', 'jurisdiction': 'fictional'},
    {'id': 'DEMO-2', 'text': '演示设备 电池 保养 不得 浸水', 'effective': '2026-01-01', 'jurisdiction': 'fictional'},
]


def retrieve(query, docs=DOCS):
    terms = set(query.split())
    scored = [(len(terms & set(doc['text'].split())), doc) for doc in docs]
    return [doc for score, doc in sorted(scored, key=lambda pair: pair[0], reverse=True) if score]


def safe_tool(name, arguments):
    if name != 'lookup' or set(arguments) != {'query'} or not isinstance(arguments['query'], str):
        raise ValueError('tool denied')
    if len(arguments['query']) > 100:
        raise ValueError('query too long')
    return retrieve(arguments['query'])


def agent(query, max_steps=2):
    if not 1 <= max_steps <= 5:
        raise ValueError('invalid step budget')
    events = [{'state': 'received', 'query': query}]
    hits = safe_tool('lookup', {'query': query})
    events.append({'state': 'retrieved', 'ids': [doc['id'] for doc in hits]})
    # Deterministic controller; no LLM planning is performed in this offline experiment.
    events.append({'state': 'answered' if hits else 'abstained'})
    return {'events': events, 'citations': [doc['id'] for doc in hits], 'llm_called': False}


def run(unit):
    if unit == '01-agent-foundations':
        return agent('售后服务期')
    if unit == '02-huggingface':
        raw = '模型 测试 模型'.split()
        vocabulary = {token: i for i, token in enumerate(sorted(set(raw)))}
        return {'toy_token_ids': [vocabulary[token] for token in raw], 'not_hf_tokenizer': True}
    if unit == '03-bert-sentiment':
        return classify_metrics([0, 0, 0, 1], [0, 0, 0, 0])
    if unit == '04-gpt2-generation':
        ids = [2, 7, 9, 3]
        return {'input_ids': ids[:-1], 'next_token_labels': ids[1:], 'trained_model': False}
    if unit == '05-local-serving':
        params, bytes_per_weight = 1_000_000_000, 2
        return {'weights_only_gib': params*bytes_per_weight/1024**3, 'includes_kv_or_runtime': False}
    if unit == '06-qwen-sft':
        messages = [{'role': 'user', 'content': '查找售后条款'}, {'role': 'assistant', 'content': '请提供条款原文。'}]
        return {'schema_ok': validate_messages(messages), 'records': 1}
    if unit == '07-qlora-gguf':
        return {'toy_int8': quantize([0.12, -0.28, 0.64], 0.1), 'gguf_created': False}
    if unit == '08-distributed-training':
        shards = [list(range(8))[rank::2] for rank in range(2)]
        return {'shards': shards, 'effective_batch': 2*4*2, 'distributed_backend_started': False}
    if unit == '09-distillation':
        teacher, student = [0.8, 0.2], [0.6, 0.4]
        return {'kl_teacher_student': sum(p*math.log(p/q) for p, q in zip(teacher, student)), 'student_trained': False}
    if unit == '10-inference-quantization':
        values = [0.11, 0.25, -0.32]
        return {'fine': quantize(values, 0.01), 'coarse': quantize(values, 0.1)}
    if unit == '11-serving-parity':
        train = {'template': 'v1', 'adapter': 'sha-A', 'temperature': 0}
        serve = {'template': 'v2', 'adapter': 'sha-A', 'temperature': 0.7}
        return {'mismatches': [key for key in train if train[key] != serve[key]]}
    if unit == '12-evaluation':
        results = [True, True, False, True]
        return {'cases': len(results), 'passed': sum(results), 'rate': sum(results)/len(results), 'benchmark': 'synthetic'}
    if unit == '13-dialogue-data':
        samples = ['请帮助我', '请帮助我', '我需要冷静一下']
        return {'total': len(samples), 'unique_hashes': len({hashlib.sha256(s.encode()).hexdigest() for s in samples})}
    if unit == '14-dialogue-project':
        return {'holdout': classify_metrics([1, 0, 1, 0], [1, 0, 0, 0]), 'synthetic_predictions': True}
    if unit == '15-llamaindex-rag':
        return {'hits': retrieve('售后服务期'), 'framework_used': False}
    if unit == '16-embedding-chroma':
        return {'same': cosine([1, 0], [1, 0]), 'orthogonal': cosine([1, 0], [0, 1]), 'chroma_started': False}
    if unit == '17-dify-rag':
        return {'workflow': ['input', 'retrieve', 'context', 'answer'], 'empty_context_action': 'abstain', 'dify_started': False}
    if unit == '18-ragflow':
        chunks = [{'id': 'p1-row1', 'page': 1, 'text': '服务期 30天'}, {'id': 'p1-row2', 'page': 1, 'text': '电池 不得浸水'}]
        return {'chunks': chunks, 'ragflow_started': False}
    if unit == '19-legal-design':
        return {'allowed_docs': [d['id'] for d in DOCS if d['effective'] <= '2026-02-01' and d['jurisdiction'] == 'fictional'], 'real_law': False}
    if unit == '20-legal-deployment':
        hits = retrieve('售后服务期')
        return {'citations_valid': all(d['id'] in {doc['id'] for doc in DOCS} for d in hits), 'answerable': bool(hits), 'real_law': False}
    if unit == '21-legal-sft':
        return {'safe_training_target': {'role': 'assistant', 'content': '仅依据检索资料回答，资料不足时拒答。'}, 'facts_stored_in_weights': False}
    if unit == '22-dify-agent':
        try:
            safe_tool('shell', {'command': 'echo unsafe'})
        except ValueError:
            return {'unauthorized_tool': 'denied', 'dify_started': False}
        raise AssertionError('policy failed')
    if unit == '23-langgraph':
        return {'path': agent('不存在的资料')['events'], 'framework_used': False}
    if unit == '24-deepseek':
        return {'request_contract': {'model': '<从账户模型列表确认>', 'messages': [{'role': 'user', 'content': '说明引用边界'}]}, 'network_called': False}
    if unit == '25-multimodal':
        segments = [{'start_s': 0, 'end_s': 2, 'text': '请查找保养说明'}]
        return {'segments': segments, 'consent': 'synthetic', 'recognizer_called': False}
    if unit == '26-capstone':
        cases = [('售后服务期', 'answered'), ('找不到', 'abstained')]
        results = [agent(query)['events'][-1]['state'] == expected for query, expected in cases]
        return {'passed': sum(results), 'total': len(results), 'all_passed': all(results), 'llm_called': False}
    raise ValueError('unknown unit')


if __name__ == '__main__':
    print(json.dumps(run(sys.argv[1]), ensure_ascii=False, indent=2))
